import { Component, OnInit } from '@angular/core';
import { Courses } from '../courses';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  course : Courses = new Courses;
  courseDuration:Number = null;
  flag:boolean=false;
  myForm:FormGroup;
  courseArray: Courses[] = [
    { courseName: "HTML",  courseDuration: 15 },
    {  courseName: "CSS",  courseDuration: 25 },
    {  courseName: "Bootstrap",  courseDuration: 35 }
  ]
  
  constructor(private fb:FormBuilder) {
    this.validation();
  }
    
  ngOnInit() {
  }
  validation()
  {
    this.myForm = this.fb.group({
      courseName:['',Validators.requiredTrue],
      courseDuration:['',Validators.requiredTrue]
    })
  }
  AddCourse()
  {
    Object.assign(this.course,this.myForm.value);
    console.log(this.course)
    this.courseArray.push(this.course);
   
  }
  getDuration(courseName:String)
  {
    console.log(courseName);
    this.courseArray.forEach(course =>{
      if((course.courseName).toLowerCase() == courseName.toLowerCase())
      {
        this.flag=true;
        this.courseDuration = course.courseDuration;
      }
      console.log(this.courseDuration);
    })
  }
}