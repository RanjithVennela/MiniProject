import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Courses } from './courses';

@Injectable()
export class CourseService {
courseArr:Courses[]
  constructor(private http:HttpClient) { }
  getCourseData():Observable<any>{
  return  this.http.get("./assets/courses.json")
  }

}
