import { Component, OnInit } from '@angular/core';
import { Courses } from '../courses';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CourseService } from '../course.service';
import { INVALID } from '@angular/forms/src/model';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  cDuration:Number = null;
  flag:boolean=false;
  myForm:FormGroup;
  courseArray:Courses[]=[];
  flag1:boolean=true;
  constructor(private fb:FormBuilder, private courseservice:CourseService) {
    this.myForm = this.fb.group({
      courseName:['',Validators.required],
      courseDuration:['',Validators.required]
    })
  }
    
  ngOnInit() {
    this.courseservice.getCourse().subscribe((result:Courses[])=>this.courseArray=result);
  }
 
  AddCourse()
  {
    if(this.myForm.valid)
    {
     
      this.courseservice.addCourse(this.myForm.value);
      this.courseservice.getCourse().subscribe(result=>this.courseArray=result);
      this.myForm.reset(); 
    }
    else
    {
      alert("All Fields are required");
      this.flag1 = false
    }
     
  }

  getDuration(courseName:String)
  {

    this.courseArray.forEach(course =>{
      if((course.courseName).toLowerCase() == courseName.toLowerCase())
      {
        this.flag=true;
        this.cDuration = course.courseDuration;
      }
  
    })
  }
}